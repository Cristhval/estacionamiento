package com.mistletoe.estaciona.base.models;

public class Cliente extends Usuario{
    public Cliente(Integer id, String nombre, String apellido, String correoElectronico) {
        super(id, nombre, apellido, correoElectronico);
    }

}
