import type Order_1 from "./Order.js";
interface Sort {
    orders: Array<Order_1 | undefined>;
}
export default Sort;
